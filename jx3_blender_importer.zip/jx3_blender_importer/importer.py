"""FBX import and repair workflow for the JX3 Blender importer."""

from __future__ import annotations

import os
from typing import Iterable, List, Optional

import bpy

from . import armature
from . import materials


def import_and_fix(
    context: bpy.types.Context,
    fbx_path: str,
    texture_dir: str = "",
    emission_strength: float = 1.0,
    repair_armature: bool = True,
    deep_armature_repair: bool = False,
    use_diffuse_alpha: bool = False,
) -> dict:
    """Import a JX3 FBX file and repair its materials/armature."""

    if not fbx_path or not os.path.isfile(fbx_path):
        raise FileNotFoundError(f"FBX 文件不存在: {fbx_path}")

    before = set(bpy.data.objects)
    _import_fbx(fbx_path)
    imported_objects = [obj for obj in bpy.data.objects if obj not in before]

    for obj in bpy.context.selected_objects:
        obj.select_set(False)
    for obj in imported_objects:
        obj.select_set(True)
    if imported_objects:
        context.view_layer.objects.active = imported_objects[0]

    return fix_objects(
        context,
        imported_objects,
        texture_dir=texture_dir or guess_texture_dir(fbx_path),
        emission_strength=emission_strength,
        repair_armature=repair_armature,
        deep_armature_repair=deep_armature_repair,
        use_diffuse_alpha=use_diffuse_alpha,
    )


def import_only(context: bpy.types.Context, fbx_path: str) -> dict:
    """Import a JX3 FBX file without rebuilding materials or repairing armatures."""

    if not fbx_path or not os.path.isfile(fbx_path):
        raise FileNotFoundError(f"FBX 文件不存在: {fbx_path}")

    before = set(bpy.data.objects)
    _import_fbx(fbx_path)
    imported_objects = [obj for obj in bpy.data.objects if obj not in before]

    for obj in bpy.context.selected_objects:
        obj.select_set(False)
    for obj in imported_objects:
        obj.select_set(True)
    if imported_objects:
        context.view_layer.objects.active = imported_objects[0]

    report = {
        "objects": len(imported_objects),
        "texture_dir": guess_texture_dir(fbx_path),
        "texture_sets": 0,
        "materials": {"materials_seen": 0, "materials_fixed": 0, "materials_missing": []},
        "armatures": {"armatures_seen": 0, "armatures_fixed": 0, "messages": []},
    }
    print("[JX3 Importer] 导入完成，未自动修复材质或骨骼。")
    print(f"  导入对象数量: {report['objects']}")
    print(f"  自动识别贴图目录: {report['texture_dir'] or '未识别'}")
    return report


def fix_selected(
    context: bpy.types.Context,
    texture_dir: str = "",
    emission_strength: float = 1.0,
    repair_armature: bool = True,
    deep_armature_repair: bool = False,
    use_diffuse_alpha: bool = False,
) -> dict:
    """Repair currently selected mesh and armature objects."""

    objects = list(context.selected_objects)
    if not objects:
        raise RuntimeError("请先选择需要修复的 Mesh 或 Armature。")

    return fix_objects(
        context,
        objects,
        texture_dir=texture_dir or guess_texture_dir_from_objects(objects),
        emission_strength=emission_strength,
        repair_armature=repair_armature,
        deep_armature_repair=deep_armature_repair,
        use_diffuse_alpha=use_diffuse_alpha,
    )


def fix_materials_selected(
    context: bpy.types.Context,
    texture_dir: str = "",
    emission_strength: float = 1.0,
    use_diffuse_alpha: bool = True,
    force_opaque: bool = False,
) -> dict:
    """Only repair materials for currently selected mesh objects."""

    objects = list(context.selected_objects)
    if not objects:
        raise RuntimeError("请先选择需要修复材质的 Mesh 或 Armature。")

    scoped_objects = _expand_related_objects(objects)
    texture_dir = texture_dir or guess_texture_dir_from_objects(scoped_objects)
    progress_total = max(materials.count_material_slots(scoped_objects), 1)
    wm = context.window_manager
    wm.progress_begin(0, progress_total)
    try:
        wm.progress_update(0)
        _find_missing_files(texture_dir)
        texture_index = materials.scan_texture_directory(texture_dir)
        material_report = materials.rebuild_materials_for_objects(
            scoped_objects,
            texture_index,
            emission_strength=emission_strength,
            use_diffuse_alpha=use_diffuse_alpha,
            force_opaque=force_opaque,
            progress_callback=wm.progress_update,
        )
    finally:
        wm.progress_end()
    report = {
        "objects": len(scoped_objects),
        "texture_dir": texture_dir,
        "texture_sets": len(texture_index),
        "materials": material_report,
        "armatures": {"armatures_seen": 0, "armatures_fixed": 0, "messages": []},
    }
    print_report(report)
    return report


def fix_armature_selected(
    context: bpy.types.Context,
    deep_armature_repair: bool = False,
) -> dict:
    """Only repair armatures for currently selected mesh/armature objects."""

    objects = list(context.selected_objects)
    if not objects:
        raise RuntimeError("请先选择需要修复骨骼的 Mesh 或 Armature。")

    scoped_objects = _expand_related_objects(objects)
    armature_report = armature.repair_armatures(
        context,
        scoped_objects,
        do_repair=True,
        deep_repair=deep_armature_repair,
    )
    report = {
        "objects": len(scoped_objects),
        "texture_dir": "",
        "texture_sets": 0,
        "materials": {"materials_seen": 0, "materials_fixed": 0, "materials_missing": []},
        "armatures": armature_report,
    }
    print_report(report)
    return report


def fix_objects(
    context: bpy.types.Context,
    objects: Iterable[bpy.types.Object],
    texture_dir: str = "",
    emission_strength: float = 1.0,
    repair_armature: bool = True,
    deep_armature_repair: bool = False,
    use_diffuse_alpha: bool = False,
) -> dict:
    """Run material and armature repair on an object collection."""

    scoped_objects = _expand_related_objects(list(objects))
    _find_missing_files(texture_dir)
    texture_index = materials.scan_texture_directory(texture_dir)
    material_report = materials.rebuild_materials_for_objects(
        scoped_objects,
        texture_index,
        emission_strength=emission_strength,
        use_diffuse_alpha=use_diffuse_alpha,
        force_opaque=False,
    )

    armature_report = armature.repair_armatures(
        context,
        scoped_objects,
        do_repair=repair_armature,
        deep_repair=deep_armature_repair,
    )

    report = {
        "objects": len(scoped_objects),
        "texture_dir": texture_dir,
        "texture_sets": len(texture_index),
        "materials": material_report,
        "armatures": armature_report,
    }
    print_report(report)
    return report


def guess_texture_dir(fbx_path: str) -> str:
    """Use the common JX3 export texture layout: FBX sibling folder named tex."""

    base_dir = os.path.dirname(fbx_path)
    tex_dir = os.path.join(base_dir, "tex")
    if os.path.isdir(tex_dir):
        return tex_dir
    return base_dir


def guess_texture_dir_from_objects(objects: Iterable[bpy.types.Object]) -> str:
    """Try to infer the texture directory from existing image nodes."""

    for obj in objects:
        if obj.type != "MESH":
            continue
        for slot in obj.material_slots:
            material = slot.material
            if not material or not material.use_nodes or not material.node_tree:
                continue
            for node in material.node_tree.nodes:
                if node.bl_idname == "ShaderNodeTexImage" and node.image and node.image.filepath:
                    path = bpy.path.abspath(node.image.filepath)
                    if os.path.isfile(path):
                        return os.path.dirname(path)
    return ""


def print_report(report: dict) -> None:
    """Print a compact report to Blender's console."""

    material_report = report["materials"]
    armature_report = report["armatures"]
    print("[JX3 Importer] 修复完成")
    print(f"  对象数量: {report['objects']}")
    print(f"  贴图目录: {report['texture_dir'] or '未指定/未识别'}")
    print(f"  贴图组数量: {report['texture_sets']}")
    print(
        "  材质: "
        f"{material_report['materials_fixed']}/{material_report['materials_seen']} 已修复"
    )
    if material_report["materials_missing"]:
        print("  未匹配材质: " + ", ".join(material_report["materials_missing"]))
    print(
        "  骨架: "
        f"{armature_report['armatures_seen']} 个检查, "
        f"{armature_report['armatures_fixed']} 个修复"
    )
    for message in armature_report["messages"]:
        print(f"  - {message}")


def _import_fbx(fbx_path: str) -> None:
    kwargs = {
        "filepath": fbx_path,
        "use_custom_normals": True,
        # Texture search is intentionally moved to material repair, while
        # custom properties are still imported with the FBX.
        "use_image_search": False,
        "use_anim": False,
        "use_custom_props": True,
        "use_subsurf": False,
        "ignore_leaf_bones": True,
        "automatic_bone_orientation": False,
        "bake_space_transform": False,
    }

    try:
        bpy.ops.import_scene.fbx(**kwargs)
    except TypeError:
        # Blender occasionally changes FBX operator keyword support.
        for key in (
            "use_image_search",
            "use_anim",
            "use_custom_props",
            "use_subsurf",
            "ignore_leaf_bones",
            "automatic_bone_orientation",
            "bake_space_transform",
        ):
            kwargs.pop(key, None)
        bpy.ops.import_scene.fbx(**kwargs)


def _find_missing_files(texture_dir: str) -> bool:
    """Let Blender resolve missing image paths from the chosen texture folder."""

    if not texture_dir or not os.path.isdir(texture_dir):
        return False

    try:
        bpy.ops.file.find_missing_files(directory=texture_dir)
        return True
    except (AttributeError, RuntimeError, TypeError):
        return False


def _expand_related_objects(objects: List[bpy.types.Object]) -> List[bpy.types.Object]:
    result = []
    seen = set()

    def add(obj: Optional[bpy.types.Object]) -> None:
        if obj and obj.name not in seen:
            seen.add(obj.name)
            result.append(obj)

    for obj in objects:
        add(obj)
        if obj.type == "ARMATURE":
            for candidate in bpy.data.objects:
                if candidate.type == "MESH" and _mesh_uses_armature(candidate, obj):
                    add(candidate)
        elif obj.type == "MESH":
            arm_obj = obj.find_armature()
            add(arm_obj)

    return result


def _mesh_uses_armature(mesh_obj: bpy.types.Object, arm_obj: bpy.types.Object) -> bool:
    if mesh_obj.parent == arm_obj:
        return True
    for modifier in mesh_obj.modifiers:
        if modifier.type == "ARMATURE" and modifier.object == arm_obj:
            return True
    return False
