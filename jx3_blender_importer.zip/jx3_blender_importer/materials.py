"""Material reconstruction helpers for JX3 FBX exports."""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from typing import Dict, Iterable, Optional

import bpy


TEXTURE_PATTERN = re.compile(
    r"^(?P<base>.+)_(?P<kind>Diffuse|MRE|TangentSpace_Normal)\.(?P<ext>tga|png|dds|jpg|jpeg|tif|tiff)$",
    re.IGNORECASE,
)
TEXTURE_SET_PATTERN = re.compile(r"^(?P<family>.+)_s(?P<slot>\d+)_c(?P<color>\d+)$", re.IGNORECASE)
META_FACE_FAMILY_PATTERN = re.compile(r"(?P<family>.*meta_face_body_hd)_s(?P<slot>\d+)_c0", re.IGNORECASE)

KIND_ALIASES = {
    "diffuse": "diffuse",
    "tangentspace_normal": "normal",
    "tangentspacenormal": "normal",
    "mre": "mre",
}


@dataclass
class TextureSet:
    """The three texture slots used by exported JX3 materials."""

    base_name: str
    diffuse: Optional[str] = None
    normal: Optional[str] = None
    mre: Optional[str] = None

    @property
    def complete_count(self) -> int:
        return sum(1 for path in (self.diffuse, self.normal, self.mre) if path)


def scan_texture_directory(texture_dir: str) -> Dict[str, TextureSet]:
    """Index JX3 textures by material base name.

    Expected file names look like:
    ``f2_5524v_body_hd_s0_c1_Diffuse.tga``
    ``f2_5524v_body_hd_s0_c1_TangentSpace_Normal.tga``
    ``f2_5524v_body_hd_s0_c1_MRE.tga``
    """

    index: Dict[str, TextureSet] = {}
    if not texture_dir or not os.path.isdir(texture_dir):
        return index

    for dirpath, _dirnames, filenames in os.walk(texture_dir):
        for filename in filenames:
            match = TEXTURE_PATTERN.match(filename)
            if not match:
                continue

            base_name = match.group("base")
            kind_key = match.group("kind").lower()
            kind_key = kind_key.replace("_", "")
            kind = KIND_ALIASES.get(kind_key)
            if not kind:
                continue

            lookup_key = normalize_material_key(base_name)
            texture_set = index.setdefault(lookup_key, TextureSet(base_name=base_name))
            setattr(texture_set, kind, os.path.join(dirpath, filename))

    return index


def normalize_material_key(name: str) -> str:
    """Normalize Blender material names and texture base names for matching."""

    value = os.path.basename(str(name or ""))
    value = os.path.splitext(value)[0]
    value = value.replace("Material::", "")
    if "::" in value:
        value = value.split("::")[-1]
    value = re.sub(r"\.\d{3}$", "", value)
    value = re.sub(r"_(Diffuse|MRE|TangentSpace_Normal)$", "", value, flags=re.IGNORECASE)
    return value.strip().lower()


def find_texture_set(
    material: bpy.types.Material,
    texture_index: Dict[str, TextureSet],
    obj: Optional[bpy.types.Object] = None,
    slot_index: int = 0,
) -> Optional[TextureSet]:
    """Find the best texture set for a Blender material."""

    material_candidates = _material_candidates(material)
    object_candidates = _object_slot_candidates(obj, slot_index, material_candidates)
    candidates = material_candidates + object_candidates

    special_texture_set = _find_special_meta_face_texture_set(material_candidates, texture_index)
    if special_texture_set:
        return special_texture_set

    for key in candidates:
        if key in texture_index:
            return texture_index[key]

    for candidate in candidates:
        for key, texture_set in sorted(texture_index.items(), key=lambda item: len(item[0]), reverse=True):
            if key and _is_safe_fuzzy_match(candidate, key):
                return texture_set

    return None


def _material_candidates(material: bpy.types.Material) -> list:
    candidates = [normalize_material_key(material.name)]

    if material.use_nodes and material.node_tree:
        for node in material.node_tree.nodes:
            if node.bl_idname == "ShaderNodeTexImage" and node.image:
                candidates.append(normalize_material_key(node.image.name))
                candidates.append(normalize_material_key(node.image.filepath))

    return _unique_nonempty(candidates)


def rebuild_materials_for_objects(
    objects: Iterable[bpy.types.Object],
    texture_index: Dict[str, TextureSet],
    emission_strength: float = 1.0,
    use_diffuse_alpha: bool = True,
    force_opaque: bool = False,
    progress_callback=None,
) -> dict:
    """Rebuild all material node trees for the provided mesh objects."""

    report = {
        "materials_seen": 0,
        "materials_fixed": 0,
        "materials_missing": [],
    }

    progress_value = 0
    for obj in objects:
        if obj.type != "MESH":
            continue

        for slot_index, slot in enumerate(obj.material_slots):
            material = slot.material
            if not material:
                progress_value += 1
                _notify_progress(progress_callback, progress_value)
                continue

            _enable_double_sided_material(material)
            report["materials_seen"] += 1
            texture_set = find_texture_set(material, texture_index, obj=obj, slot_index=slot_index)
            if not texture_set:
                report["materials_missing"].append(f"{obj.name}[{slot_index}]: {material.name}")
                progress_value += 1
                _notify_progress(progress_callback, progress_value)
                continue

            if _material_used_by_other_slots(material, objects, obj, slot_index):
                material = material.copy()
                slot.material = material
                _enable_double_sided_material(material)
            rebuild_material(material, texture_set, emission_strength, use_diffuse_alpha, force_opaque)
            report["materials_fixed"] += 1
            progress_value += 1
            _notify_progress(progress_callback, progress_value)

    return report


def count_material_slots(objects: Iterable[bpy.types.Object]) -> int:
    return sum(len(obj.material_slots) for obj in objects if obj.type == "MESH")


def _notify_progress(progress_callback, value: int) -> None:
    if progress_callback:
        progress_callback(value)


def _object_slot_candidates(
    obj: Optional[bpy.types.Object],
    slot_index: int,
    material_candidates: Optional[list] = None,
) -> list:
    if not obj:
        return []

    raw_names = [obj.name]
    if getattr(obj, "data", None):
        raw_names.append(obj.data.name)

    bases = []
    for raw_name in raw_names:
        base = normalize_material_key(raw_name)
        base = re.sub(r"\.mesh$", "", base)
        base = re.sub(r"_(mesh|model|geometry)$", "", base)
        if base and base not in bases:
            bases.append(base)

    candidates = []
    for base in bases:
        candidates.append(base)
        color_groups = (0,) if _looks_like_meta_face_family(base, material_candidates) else (0, 1, 2)
        for color_group in color_groups:
            candidates.append(f"{base}_s{slot_index}_c{color_group}")
    return candidates


def _find_special_meta_face_texture_set(
    candidates: list,
    texture_index: Dict[str, TextureSet],
) -> Optional[TextureSet]:
    for candidate in candidates:
        if any(alias in candidate for alias in ("eye_weep", "weep")):
            texture_set = _find_meta_face_slot(texture_index, 3)
            if texture_set:
                return texture_set
        if any(alias in candidate for alias in ("eye_cornea", "cornea")):
            texture_set = _find_meta_face_slot(texture_index, 4)
            if texture_set:
                return texture_set

        match = META_FACE_FAMILY_PATTERN.search(candidate)
        if match:
            key = f"{match.group('family')}_s{int(match.group('slot'))}_c0"
            if key in texture_index:
                return texture_index[key]
    return None


def _find_meta_face_slot(texture_index: Dict[str, TextureSet], slot_index: int) -> Optional[TextureSet]:
    suffix = f"meta_face_body_hd_s{slot_index}_c0"
    for key, texture_set in texture_index.items():
        if key.endswith(suffix):
            return texture_set
    return None


def _looks_like_meta_face_family(base: str, material_candidates: Optional[list] = None) -> bool:
    if "meta_face_body_hd" in base:
        return True
    return any("meta_face_body_hd" in candidate for candidate in (material_candidates or []))


def _is_safe_fuzzy_match(candidate: str, texture_key: str) -> bool:
    if not candidate:
        return False

    if texture_key in candidate:
        return True

    if candidate in texture_key:
        # Do not let generic family names like f2_meta_face_body_hd match the
        # first available face slot. Face slots must match exact s*_c0 keys.
        return bool(TEXTURE_SET_PATTERN.match(candidate))

    return False


def _unique_nonempty(values: Iterable[str]) -> list:
    result = []
    for value in values:
        if value and value not in result:
            result.append(value)
    return result


def _material_used_by_other_slots(
    material: bpy.types.Material,
    objects: Iterable[bpy.types.Object],
    current_obj: bpy.types.Object,
    current_slot_index: int,
) -> bool:
    for obj in objects:
        if obj.type != "MESH":
            continue
        for slot_index, slot in enumerate(obj.material_slots):
            if obj == current_obj and slot_index == current_slot_index:
                continue
            if slot.material == material:
                return True
    return False


def rebuild_material(
    material: bpy.types.Material,
    texture_set: TextureSet,
    emission_strength: float = 1.0,
    use_diffuse_alpha: bool = True,
    force_opaque: bool = False,
) -> None:
    """Build a Blender 4.x Principled material from Diffuse, Normal, and MRE."""

    texture_key = normalize_material_key(texture_set.base_name)
    if _is_meta_face_texture_key(texture_key):
        rebuild_meta_face_material(material, texture_set, texture_key)
        return

    material.use_nodes = True
    material.name = texture_set.base_name
    _enable_double_sided_material(material)
    alpha_mode = _choose_alpha_mode(texture_set, use_diffuse_alpha, force_opaque)
    effective_alpha = alpha_mode != "OPAQUE"
    _set_material_blend_method(material, alpha_mode)
    if effective_alpha and hasattr(material, "surface_render_method"):
        try:
            material.surface_render_method = "DITHERED" if alpha_mode == "HASHED" else "BLENDED"
        except TypeError:
            pass
    if hasattr(material, "use_screen_refraction"):
        material.use_screen_refraction = False

    tree = material.node_tree
    nodes = tree.nodes
    links = tree.links
    nodes.clear()

    output = nodes.new("ShaderNodeOutputMaterial")
    output.location = (620, 0)

    principled = nodes.new("ShaderNodeBsdfPrincipled")
    principled.location = (360, 0)
    if "Alpha" in principled.inputs:
        principled.inputs["Alpha"].default_value = 1.0
    links.new(principled.outputs["BSDF"], output.inputs["Surface"])

    _add_standard_texture_nodes(nodes, links, principled, texture_set, alpha_mode, emission_strength)


def rebuild_meta_face_material(
    material: bpy.types.Material,
    texture_set: TextureSet,
    texture_key: str,
) -> None:
    """Force all *_meta_face_body_hd_s*_c0 slots through JX3 face rules."""

    if texture_key == "f2_meta_face_body_hd_s3_c0":
        rebuild_eye_weep_material(material, texture_set)
        return
    if texture_key == "f2_meta_face_body_hd_s4_c0":
        rebuild_eye_cornea_material(material, texture_set)
        return

    material.use_nodes = True
    material.name = texture_set.base_name
    _enable_double_sided_material(material)
    alpha_mode = _choose_meta_face_alpha_mode(texture_key, texture_set)
    effective_alpha = alpha_mode != "OPAQUE"
    _set_material_blend_method(material, alpha_mode)
    if effective_alpha and hasattr(material, "surface_render_method"):
        try:
            material.surface_render_method = "DITHERED" if alpha_mode == "HASHED" else "BLENDED"
        except TypeError:
            pass
    if hasattr(material, "use_screen_refraction"):
        material.use_screen_refraction = False

    tree = material.node_tree
    nodes = tree.nodes
    links = tree.links
    nodes.clear()

    output = nodes.new("ShaderNodeOutputMaterial")
    output.location = (620, 0)

    principled = nodes.new("ShaderNodeBsdfPrincipled")
    principled.location = (360, 0)
    if "Alpha" in principled.inputs:
        principled.inputs["Alpha"].default_value = 1.0
    links.new(principled.outputs["BSDF"], output.inputs["Surface"])

    _add_standard_texture_nodes(nodes, links, principled, texture_set, alpha_mode, 1.0)


def _add_standard_texture_nodes(
    nodes,
    links,
    principled,
    texture_set: TextureSet,
    alpha_mode: str,
    emission_strength: float,
) -> None:
    effective_alpha = alpha_mode != "OPAQUE"

    if texture_set.diffuse:
        diffuse_alpha_mode = _choose_diffuse_image_alpha_mode(texture_set, alpha_mode)
        diffuse = _make_image_node(
            nodes,
            texture_set.diffuse,
            "sRGB",
            (-620, 160),
            "Diffuse",
            alpha_mode=diffuse_alpha_mode,
        )
        _link_socket(links, diffuse.outputs, principled.inputs, ["Color"], ["Base Color"])
        if effective_alpha:
            _link_socket(links, diffuse.outputs, principled.inputs, ["Alpha"], ["Alpha"])

    if texture_set.normal:
        normal_tex = _make_image_node(
            nodes,
            texture_set.normal,
            "Non-Color",
            (-620, -160),
            "Normal",
            alpha_mode="NONE",
        )
        normal_map = nodes.new("ShaderNodeNormalMap")
        normal_map.location = (-170, -180)
        _link_socket(links, normal_tex.outputs, normal_map.inputs, ["Color"], ["Color"])
        _link_socket(links, normal_map.outputs, principled.inputs, ["Normal"], ["Normal"])

    if texture_set.mre:
        mre_tex = _make_image_node(
            nodes,
            texture_set.mre,
            "Non-Color",
            (-620, -500),
            "MRE",
            alpha_mode="NONE",
        )
        separate = _make_separate_color_node(nodes)
        separate.location = (-360, -500)
        _link_socket(links, mre_tex.outputs, separate.inputs, ["Color"], ["Color", "Image"])

        _link_socket(links, separate.outputs, principled.inputs, ["Red", "R"], ["Metallic"])
        _link_socket(links, separate.outputs, principled.inputs, ["Green", "G"], ["Roughness"])
        _connect_emission(nodes, links, separate, principled, emission_strength)


def _is_meta_face_texture_key(texture_key: str) -> bool:
    return "meta_face_body_hd_s" in texture_key and texture_key.endswith("_c0")


def _choose_meta_face_alpha_mode(texture_key: str, texture_set: TextureSet) -> str:
    # Regular face/skin slots are opaque unless their Diffuse genuinely carries
    # a non-opaque mask. Eye overlay slots are handled by their special builders.
    diffuse_stats = _sample_image_channel(texture_set.diffuse, 3) if texture_set.diffuse else None
    if not diffuse_stats or diffuse_stats["min"] > 0.98:
        return "OPAQUE"
    if diffuse_stats["nonopaque_fraction"] > 0.85 and diffuse_stats["transparent_fraction"] < 0.10:
        return "BLEND"
    if diffuse_stats["min"] < 0.05 and diffuse_stats["max"] > 0.95:
        return "HASHED"
    return "BLEND"


def rebuild_eye_weep_material(material: bpy.types.Material, texture_set: TextureSet) -> None:
    """Recreate JX3 eye_weep wet tear overlay.

    Source material: f2_meta_face_body_hd_s3_c0 / eye_weep.
    Observed JX3 properties: Metallic=1, Opacity=0.7, Roughness=0.1,
    Specular=0.1, Weep_Color=(204,204,204), Weep_Density=1.8,
    Weep_Roughness=0.1, Weep_Spec=28.
    """

    material.use_nodes = True
    material.name = "eye_weep"
    _enable_double_sided_material(material)
    _set_material_blend_method(material, "BLEND")
    material.diffuse_color = (0.8, 0.8, 0.8, 0.7)
    if hasattr(material, "surface_render_method"):
        try:
            material.surface_render_method = "BLENDED"
        except TypeError:
            pass
    if hasattr(material, "use_screen_refraction"):
        material.use_screen_refraction = True

    tree = material.node_tree
    nodes = tree.nodes
    links = tree.links
    nodes.clear()

    output = nodes.new("ShaderNodeOutputMaterial")
    output.location = (760, 0)

    principled = nodes.new("ShaderNodeBsdfPrincipled")
    principled.location = (500, 0)
    _set_principled_input(principled, ["Base Color"], (0.8, 0.8, 0.8, 1.0))
    _set_principled_input(principled, ["Metallic"], 1.0)
    _set_principled_input(principled, ["Roughness"], 0.1)
    _set_principled_input(principled, ["Specular IOR Level", "Specular"], 0.1)
    _set_principled_input(principled, ["Coat Weight", "Clearcoat"], 1.0)
    _set_principled_input(principled, ["Coat Roughness", "Clearcoat Roughness"], 0.1)
    _set_principled_input(principled, ["Alpha"], 0.7)
    links.new(principled.outputs["BSDF"], output.inputs["Surface"])

    if texture_set.diffuse:
        diffuse = _make_image_node(
            nodes,
            texture_set.diffuse,
            "sRGB",
            (-700, 160),
            "Diffuse / eye_weep mask",
            alpha_mode="PREMUL",
        )
        alpha_scale = nodes.new("ShaderNodeMath")
        alpha_scale.operation = "MULTIPLY"
        alpha_scale.location = (190, -160)
        alpha_scale.use_clamp = True
        alpha_scale.inputs[1].default_value = 0.7

        alpha_output = _get_socket(diffuse.outputs, ["Alpha"])
        alpha_input = _get_socket(principled.inputs, ["Alpha"])
        if alpha_output and alpha_input:
            links.new(alpha_output, alpha_scale.inputs[0])
            links.new(alpha_scale.outputs[0], alpha_input)

    if texture_set.normal:
        normal_tex = _make_image_node(
            nodes,
            texture_set.normal,
            "Non-Color",
            (-700, -160),
            "Normal",
            alpha_mode="NONE",
        )
        normal_map = nodes.new("ShaderNodeNormalMap")
        normal_map.location = (190, -360)
        _set_principled_input(normal_map, ["Strength"], 1.0)
        _link_socket(links, normal_tex.outputs, normal_map.inputs, ["Color"], ["Color"])
        _link_socket(links, normal_map.outputs, principled.inputs, ["Normal"], ["Normal"])


def rebuild_eye_cornea_material(material: bpy.types.Material, texture_set: TextureSet) -> None:
    """Recreate JX3 eye_cornea as a transparent multiply-style overlay.

    Source material: f2_meta_face_body_hd_s4_c0 / eye_cornea.
    Key properties observed from JX3: DisA=0.25, Roughness=0.2,
    Specular=0.001. Blender has no direct per-material multiply compositing
    over underlying geometry, so this uses a premultiplied alpha overlay that
    visually matches the transparent multiply mask in material preview.
    """

    material.use_nodes = True
    material.name = "eye_cornea"
    _enable_double_sided_material(material)
    _set_material_blend_method(material, "BLEND")
    material.diffuse_color = (1.0, 1.0, 1.0, 0.25)
    if hasattr(material, "surface_render_method"):
        try:
            material.surface_render_method = "BLENDED"
        except TypeError:
            pass
    if hasattr(material, "use_screen_refraction"):
        material.use_screen_refraction = True

    tree = material.node_tree
    nodes = tree.nodes
    links = tree.links
    nodes.clear()

    output = nodes.new("ShaderNodeOutputMaterial")
    output.location = (680, 0)

    principled = nodes.new("ShaderNodeBsdfPrincipled")
    principled.location = (420, 0)
    _set_principled_input(principled, ["Metallic"], 0.0)
    _set_principled_input(principled, ["Roughness"], 0.2)
    _set_principled_input(principled, ["Specular IOR Level", "Specular"], 0.001)
    _set_principled_input(principled, ["Alpha"], 0.25)
    links.new(principled.outputs["BSDF"], output.inputs["Surface"])

    if texture_set.diffuse:
        diffuse = _make_image_node(
            nodes,
            texture_set.diffuse,
            "sRGB",
            (-620, 150),
            "Diffuse / eye_cornea multiply mask",
            alpha_mode="PREMUL",
        )
        alpha_scale = nodes.new("ShaderNodeMath")
        alpha_scale.operation = "MULTIPLY"
        alpha_scale.location = (120, -160)
        alpha_scale.use_clamp = True
        alpha_scale.inputs[1].default_value = 1.0

        _link_socket(links, diffuse.outputs, principled.inputs, ["Color"], ["Base Color"])
        alpha_output = _get_socket(diffuse.outputs, ["Alpha"])
        alpha_input = _get_socket(principled.inputs, ["Alpha"])
        if alpha_output and alpha_input:
            links.new(alpha_output, alpha_scale.inputs[0])
            links.new(alpha_scale.outputs[0], alpha_input)

    if texture_set.normal:
        normal_tex = _make_image_node(
            nodes,
            texture_set.normal,
            "Non-Color",
            (-620, -150),
            "Normal",
            alpha_mode="NONE",
        )
        normal_map = nodes.new("ShaderNodeNormalMap")
        normal_map.location = (120, -360)
        _link_socket(links, normal_tex.outputs, normal_map.inputs, ["Color"], ["Color"])
        _link_socket(links, normal_map.outputs, principled.inputs, ["Normal"], ["Normal"])


def _choose_alpha_mode(texture_set: TextureSet, use_diffuse_alpha: bool, force_opaque: bool) -> str:
    """Choose opaque, hashed, or blended alpha for JX3 materials.

    JX3 Diffuse alpha is used for cutout masks, soft translucent cloth/ribbons,
    and metal material masks. Soft translucent cloth/ribbons use PREMUL image
    alpha, while metal masks use STRAIGHT image alpha.
    """

    if force_opaque or not use_diffuse_alpha or not texture_set.diffuse:
        return "OPAQUE"

    diffuse_stats = _sample_image_channel(texture_set.diffuse, 3)
    if not diffuse_stats or diffuse_stats["min"] > 0.98:
        return "OPAQUE"

    if diffuse_stats["nonopaque_fraction"] > 0.85 and diffuse_stats["transparent_fraction"] < 0.10:
        return "BLEND"

    metal_stats = _sample_image_channel(texture_set.mre, 0) if texture_set.mre else None
    if metal_stats and metal_stats["mean"] > 0.25:
        return "HASHED"

    if diffuse_stats["min"] < 0.05 and diffuse_stats["max"] > 0.95:
        return "HASHED"
    return "BLEND"


def _choose_diffuse_image_alpha_mode(texture_set: TextureSet, material_alpha_mode: str) -> str:
    if material_alpha_mode == "OPAQUE":
        return "NONE"
    if material_alpha_mode == "BLEND":
        return "PREMUL"
    return "STRAIGHT"


def _set_material_blend_method(material: bpy.types.Material, alpha_mode: str) -> None:
    try:
        material.blend_method = alpha_mode
    except TypeError:
        material.blend_method = "HASHED" if alpha_mode != "OPAQUE" else "OPAQUE"


def _enable_double_sided_material(material: bpy.types.Material) -> None:
    """Disable backface culling so cloth/ribbons render from both sides."""

    if hasattr(material, "use_backface_culling"):
        material.use_backface_culling = False
    if hasattr(material, "use_backface_culling_shadow"):
        material.use_backface_culling_shadow = False
    if hasattr(material, "show_transparent_back"):
        material.show_transparent_back = True


def _set_principled_input(principled, names, value) -> bool:
    socket = _get_socket(principled.inputs, names)
    if socket:
        socket.default_value = value
        return True
    return False


def _sample_image_channel(filepath: Optional[str], channel_index: int) -> Optional[dict]:
    if not filepath:
        return None

    try:
        image = bpy.data.images.load(filepath, check_existing=True)
        width, height = image.size
        if width <= 0 or height <= 0:
            return None
        pixels = image.pixels
    except (RuntimeError, OSError, ValueError):
        return None

    pixel_count = width * height
    if pixel_count <= 0:
        return None

    step = max(pixel_count // 4096, 1)
    values = []
    for pixel_index in range(0, pixel_count, step):
        values.append(pixels[pixel_index * 4 + channel_index])

    if not values:
        return None

    return {
        "min": min(values),
        "max": max(values),
        "mean": sum(values) / len(values),
        "transparent_fraction": sum(1 for value in values if value < 0.05) / len(values),
        "nonopaque_fraction": sum(1 for value in values if value < 0.98) / len(values),
    }


def _make_image_node(
    nodes: bpy.types.Nodes,
    filepath: str,
    color_space: str,
    location: tuple,
    label: str,
    alpha_mode: str = "STRAIGHT",
):
    node = nodes.new("ShaderNodeTexImage")
    node.location = location
    node.label = label
    node.image = bpy.data.images.load(filepath, check_existing=True)
    try:
        node.image.colorspace_settings.name = color_space
    except TypeError:
        pass
    try:
        node.image.alpha_mode = alpha_mode
    except (AttributeError, TypeError):
        pass
    return node


def _make_separate_color_node(nodes: bpy.types.Nodes):
    try:
        return nodes.new("ShaderNodeSeparateColor")
    except RuntimeError:
        return nodes.new("ShaderNodeSeparateRGB")


def _connect_emission(nodes, links, separate, principled, emission_strength: float) -> None:
    blue_socket = _get_socket(separate.outputs, ["Blue", "B"])
    if not blue_socket:
        return

    if "Emission Color" in principled.inputs:
        principled.inputs["Emission Color"].default_value = (1.0, 1.0, 1.0, 1.0)

    strength_socket = _get_socket(principled.inputs, ["Emission Strength", "Emission"])
    if not strength_socket:
        return

    if abs(emission_strength - 1.0) < 0.0001:
        links.new(blue_socket, strength_socket)
        return

    multiply = nodes.new("ShaderNodeMath")
    multiply.operation = "MULTIPLY"
    multiply.location = (-90, -560)
    multiply.inputs[1].default_value = emission_strength
    links.new(blue_socket, multiply.inputs[0])
    links.new(multiply.outputs[0], strength_socket)


def _link_socket(links, from_sockets, to_sockets, from_names, to_names) -> bool:
    source = _get_socket(from_sockets, from_names)
    target = _get_socket(to_sockets, to_names)
    if source and target:
        links.new(source, target)
        return True
    return False


def _get_socket(sockets, names):
    for name in names:
        if name in sockets:
            return sockets[name]
    return None
