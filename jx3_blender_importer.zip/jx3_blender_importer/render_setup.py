"""One-click render and compositor setup for JX3 character previews."""

from __future__ import annotations

import bpy


def apply_render_settings(
    context: bpy.types.Context,
    render_pipeline: str = "EEVEE",
    soft_glow: float = 0.35,
    hue: float = 0.5,
    saturation: float = 1.0,
    lightness: float = 1.0,
    contrast: float = 8.0,
    dispersion: float = 0.015,
    gamma: float = 1.0,
    color_temperature: float = 6500.0,
    ao_factor: float = 1.2,
    ao_distance: float = 3.0,
    gi_factor: float = 1.0,
    gi_distance: float = 3.0,
) -> dict:
    """Apply viewport/render lighting and compositor post effects."""

    scene = context.scene
    normalized_pipeline = (render_pipeline or "EEVEE").upper()
    _set_render_engine(scene, normalized_pipeline)
    if normalized_pipeline == "CYCLES":
        _set_cycles_settings(scene, ao_factor, ao_distance, gi_factor, gi_distance)
    else:
        _set_ambient_occlusion(scene, ao_factor, ao_distance)
        _set_global_illumination(scene, gi_factor, gi_distance)
    _set_color_management(scene, gamma)
    _build_compositor(
        scene,
        soft_glow=soft_glow,
        hue=hue,
        saturation=saturation,
        lightness=lightness,
        contrast=contrast,
        dispersion=dispersion,
        gamma=gamma,
        color_temperature=color_temperature,
    )
    _enable_viewport_compositor(context)

    report = {
        "engine": scene.render.engine,
        "pipeline": normalized_pipeline,
        "soft_glow": soft_glow,
        "hue": hue,
        "saturation": saturation,
        "lightness": lightness,
        "contrast": contrast,
        "dispersion": dispersion,
        "gamma": gamma,
        "color_temperature": color_temperature,
        "ao_factor": ao_factor,
        "ao_distance": ao_distance,
        "gi_factor": gi_factor,
        "gi_distance": gi_distance,
    }
    print("[JX3 Importer] 一键渲染设置完成")
    for key, value in report.items():
        print(f"  {key}: {value}")
    return report


def _set_render_engine(scene: bpy.types.Scene, render_pipeline: str) -> None:
    if render_pipeline == "CYCLES":
        try:
            scene.render.engine = "CYCLES"
            return
        except TypeError:
            pass

    # EEVEE Next gives fast AO and material preview-friendly transparency.
    try:
        scene.render.engine = "BLENDER_EEVEE_NEXT"
    except TypeError:
        try:
            scene.render.engine = "BLENDER_EEVEE"
        except TypeError:
            pass


def _set_cycles_settings(
    scene: bpy.types.Scene,
    ao_factor: float,
    ao_distance: float,
    gi_factor: float,
    gi_distance: float,
) -> None:
    cycles = getattr(scene, "cycles", None)
    if cycles:
        _set_attr_if_exists(cycles, "samples", 128)
        _set_attr_if_exists(cycles, "preview_samples", 64)
        _set_attr_if_exists(cycles, "use_denoising", True)
        _set_attr_if_exists(cycles, "max_bounces", max(2, int(gi_distance)))
        _set_attr_if_exists(cycles, "diffuse_bounces", max(1, int(gi_factor * 2)))
        _set_attr_if_exists(cycles, "glossy_bounces", max(1, int(gi_factor * 2)))
        _set_attr_if_exists(cycles, "transparent_max_bounces", 8)

    _set_world_strength(scene, gi_factor)

    # Cycles has no EEVEE-style realtime AO switch; this pass provides AO data
    # for compositor workflows while GI is controlled through bounces/world.
    view_layer = scene.view_layers[0] if scene.view_layers else None
    if view_layer and hasattr(view_layer, "use_pass_ambient_occlusion"):
        try:
            view_layer.use_pass_ambient_occlusion = ao_factor > 0.0
        except TypeError:
            pass


def _set_ambient_occlusion(scene: bpy.types.Scene, ao_factor: float, ao_distance: float) -> None:
    eevee = getattr(scene, "eevee", None)
    if not eevee:
        return

    for attr in ("use_gtao", "use_fast_gi"):
        if hasattr(eevee, attr):
            try:
                setattr(eevee, attr, True)
            except TypeError:
                pass

    _set_attr_if_exists(eevee, "gtao_factor", ao_factor)
    _set_attr_if_exists(eevee, "gtao_distance", ao_distance)
    _set_attr_if_exists(eevee, "fast_gi_thickness_near", ao_distance)


def _set_global_illumination(scene: bpy.types.Scene, gi_factor: float, gi_distance: float) -> None:
    eevee = getattr(scene, "eevee", None)
    if eevee:
        for attr in ("use_fast_gi", "use_gi_approximation"):
            _set_attr_if_exists(eevee, attr, True)
        for attr in ("fast_gi_quality", "gi_quality", "indirect_light_intensity"):
            _set_attr_if_exists(eevee, attr, gi_factor)
        for attr in ("fast_gi_distance", "fast_gi_thickness_near", "gi_distance"):
            _set_attr_if_exists(eevee, attr, gi_distance)

    _set_world_strength(scene, gi_factor)


def _set_world_strength(scene: bpy.types.Scene, strength: float) -> None:
    world = scene.world or bpy.data.worlds.new("JX3 World")
    scene.world = world
    value = max(0.0, min(1.0, 0.05 * strength))
    world.color = (value, value, value)


def _set_color_management(scene: bpy.types.Scene, gamma: float) -> None:
    view_settings = scene.view_settings
    for attr, value in (
        ("view_transform", "Filmic"),
        ("look", "Medium High Contrast"),
        ("exposure", 0.0),
        ("gamma", gamma),
    ):
        try:
            setattr(view_settings, attr, value)
        except TypeError:
            pass


def _build_compositor(
    scene: bpy.types.Scene,
    soft_glow: float,
    hue: float,
    saturation: float,
    lightness: float,
    contrast: float,
    dispersion: float,
    gamma: float,
    color_temperature: float,
) -> None:
    scene.use_nodes = True
    if hasattr(scene.render, "use_compositing"):
        scene.render.use_compositing = True

    tree = scene.node_tree
    nodes = tree.nodes
    links = tree.links
    nodes.clear()

    render_layers = nodes.new("CompositorNodeRLayers")
    render_layers.location = (-900, 0)

    glare = nodes.new("CompositorNodeGlare")
    glare.location = (-680, 0)
    glare.glare_type = "FOG_GLOW"
    glare.quality = "HIGH"
    glare.threshold = max(0.0, 1.0 - soft_glow)
    glare.size = max(6, min(9, int(6 + soft_glow * 4)))

    hue_sat = nodes.new("CompositorNodeHueSat")
    hue_sat.location = (-460, 0)
    _set_input_default(hue_sat, "Hue", hue)
    _set_input_default(hue_sat, "Saturation", saturation)
    _set_input_default(hue_sat, "Value", lightness)

    bright_contrast = nodes.new("CompositorNodeBrightContrast")
    bright_contrast.location = (-240, 0)
    _set_input_default(bright_contrast, "Bright", 0.0)
    _set_input_default(bright_contrast, "Contrast", contrast)

    lens_distortion = nodes.new("CompositorNodeLensdist")
    lens_distortion.location = (-20, 0)
    lens_distortion.use_fit = True
    _set_input_default(lens_distortion, "Distort", 0.0)
    _set_input_default(lens_distortion, "Dispersion", dispersion)

    gamma_node = nodes.new("CompositorNodeGamma")
    gamma_node.location = (200, 0)
    _set_input_default(gamma_node, "Gamma", gamma)

    color_balance = nodes.new("CompositorNodeColorBalance")
    color_balance.location = (420, 0)
    _apply_color_temperature(color_balance, color_temperature)

    composite = nodes.new("CompositorNodeComposite")
    composite.location = (680, 80)

    viewer = nodes.new("CompositorNodeViewer")
    viewer.location = (680, -100)

    _link_image(links, render_layers, glare)
    _link_image(links, glare, hue_sat)
    _link_image(links, hue_sat, bright_contrast)
    _link_image(links, bright_contrast, lens_distortion)
    _link_image(links, lens_distortion, gamma_node)
    _link_image(links, gamma_node, color_balance)
    _link_image(links, color_balance, composite)
    _link_image(links, color_balance, viewer)


def _enable_viewport_compositor(context: bpy.types.Context) -> None:
    screen = getattr(context, "screen", None)
    if not screen:
        return

    for area in screen.areas:
        if area.type != "VIEW_3D":
            continue
        for space in area.spaces:
            if space.type != "VIEW_3D":
                continue
            try:
                space.shading.type = "RENDERED"
            except TypeError:
                pass
            if hasattr(space.shading, "use_compositor"):
                try:
                    space.shading.use_compositor = "ALWAYS"
                except TypeError:
                    try:
                        space.shading.use_compositor = True
                    except TypeError:
                        pass


def _apply_color_temperature(color_balance, color_temperature: float) -> None:
    # Lower Kelvin warms the image, higher Kelvin cools it.
    shift = max(-1.0, min(1.0, (6500.0 - color_temperature) / 4500.0))
    gain = (
        max(0.0, 1.0 + 0.16 * shift),
        max(0.0, 1.0 + 0.04 * shift),
        max(0.0, 1.0 - 0.16 * shift),
    )
    try:
        color_balance.gain = gain
    except (AttributeError, TypeError):
        pass


def _link_image(links, from_node, to_node) -> None:
    from_socket = _first_socket(from_node.outputs, ("Image", 0))
    to_socket = _first_socket(to_node.inputs, ("Image", 0))
    if from_socket and to_socket:
        links.new(from_socket, to_socket)


def _set_input_default(node, socket_name: str, value) -> None:
    socket = _first_socket(node.inputs, (socket_name,))
    if socket:
        socket.default_value = value


def _first_socket(sockets, candidates):
    for candidate in candidates:
        try:
            if candidate in sockets:
                return sockets[candidate]
        except TypeError:
            pass
        if isinstance(candidate, int) and len(sockets) > candidate:
            return sockets[candidate]
    return None


def _set_attr_if_exists(obj, attr: str, value) -> None:
    if hasattr(obj, attr):
        try:
            setattr(obj, attr, value)
        except TypeError:
            pass
