"""Armature inspection and conservative repair helpers."""

from __future__ import annotations

import math
from typing import Iterable, List

import bpy
from mathutils import Vector


EPSILON = 0.0001


def repair_armatures(
    context: bpy.types.Context,
    objects: Iterable[bpy.types.Object],
    do_repair: bool = True,
    deep_repair: bool = False,
) -> dict:
    """Inspect and optionally repair armatures related to the object list."""

    scoped_objects = list(objects)
    armatures = _collect_armatures(scoped_objects)
    report = {
        "armatures_seen": len(armatures),
        "armatures_fixed": 0,
        "messages": [],
    }

    previous_active = context.view_layer.objects.active
    previous_mode = previous_active.mode if previous_active else "OBJECT"

    try:
        if context.object and context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")

        for arm_obj in armatures:
            messages_before = len(report["messages"])
            _inspect_armature(arm_obj, report)
            if do_repair:
                _repair_mesh_links(arm_obj, scoped_objects, report)
                if deep_repair:
                    _normalize_armature_object(context, arm_obj, scoped_objects, report)
                    _repair_root_hierarchy(context, arm_obj, report)
                    _recalculate_roll(context, arm_obj, report)
            if len(report["messages"]) > messages_before:
                report["armatures_fixed"] += int(do_repair)
    finally:
        if previous_active and previous_active.name in bpy.data.objects:
            context.view_layer.objects.active = previous_active
            try:
                if previous_mode != "OBJECT":
                    bpy.ops.object.mode_set(mode=previous_mode)
            except RuntimeError:
                pass

    return report


def _collect_armatures(objects: Iterable[bpy.types.Object]) -> List[bpy.types.Object]:
    result = []
    seen = set()

    def add(obj):
        if obj and obj.type == "ARMATURE" and obj.name not in seen:
            seen.add(obj.name)
            result.append(obj)

    for obj in objects:
        add(obj)
        if obj.type == "MESH":
            add(obj.find_armature())
            for modifier in obj.modifiers:
                if modifier.type == "ARMATURE":
                    add(modifier.object)

    return result


def _inspect_armature(arm_obj: bpy.types.Object, report: dict) -> None:
    bones = arm_obj.data.bones
    roots = [bone for bone in bones if bone.parent is None]

    if not bones:
        report["messages"].append(f"{arm_obj.name}: 未发现骨骼。")
        return

    if len(roots) != 1:
        report["messages"].append(f"{arm_obj.name}: 检测到 {len(roots)} 个根骨。")

    if _has_non_identity_rotation(arm_obj) or _has_non_uniform_scale(arm_obj):
        report["messages"].append(f"{arm_obj.name}: 检测到可能的导入轴向/对象变换问题。")

    zero_length = [bone.name for bone in bones if (bone.tail_local - bone.head_local).length < EPSILON]
    if zero_length:
        preview = ", ".join(zero_length[:8])
        report["messages"].append(f"{arm_obj.name}: 检测到零长度骨骼 {preview}。")


def _repair_mesh_links(arm_obj: bpy.types.Object, objects: Iterable[bpy.types.Object], report: dict) -> None:
    fixed_count = 0
    for mesh_obj in objects:
        if mesh_obj.type != "MESH":
            continue

        uses_armature = mesh_obj.find_armature() == arm_obj
        for modifier in mesh_obj.modifiers:
            if modifier.type == "ARMATURE" and modifier.object == arm_obj:
                uses_armature = True

        if not uses_armature:
            continue

        if mesh_obj.parent is None:
            mesh_obj.parent = arm_obj
            mesh_obj.parent_type = "ARMATURE"
            fixed_count += 1

        armature_modifier = _find_armature_modifier(mesh_obj)
        if not armature_modifier:
            armature_modifier = mesh_obj.modifiers.new(name="Armature", type="ARMATURE")
            fixed_count += 1
        if armature_modifier.object != arm_obj:
            armature_modifier.object = arm_obj
            fixed_count += 1

    if fixed_count:
        report["messages"].append(f"{arm_obj.name}: 修复 Mesh 与 Armature 关联 {fixed_count} 处。")


def _normalize_armature_object(
    context: bpy.types.Context,
    arm_obj: bpy.types.Object,
    objects: Iterable[bpy.types.Object],
    report: dict,
) -> None:
    if not (_has_non_identity_rotation(arm_obj) or _has_non_uniform_scale(arm_obj)):
        return

    if _has_animation(arm_obj):
        report["messages"].append(f"{arm_obj.name}: 存在动画数据，已跳过对象变换应用。")
        return

    related_meshes = [
        obj
        for obj in objects
        if obj.type == "MESH" and (obj.find_armature() == arm_obj or obj.parent == arm_obj)
    ]
    if any(_has_animation(obj) for obj in related_meshes):
        report["messages"].append(f"{arm_obj.name}: 关联 Mesh 存在动画数据，已跳过对象变换应用。")
        return

    bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.select_all(action="DESELECT")
    arm_obj.select_set(True)
    for mesh_obj in related_meshes:
        mesh_obj.select_set(True)
    context.view_layer.objects.active = arm_obj
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
    report["messages"].append(f"{arm_obj.name}: 已应用 Armature 旋转/缩放以规范导入轴向。")


def _repair_root_hierarchy(context: bpy.types.Context, arm_obj: bpy.types.Object, report: dict) -> None:
    bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.select_all(action="DESELECT")
    arm_obj.select_set(True)
    context.view_layer.objects.active = arm_obj
    bpy.ops.object.mode_set(mode="EDIT")

    edit_bones = arm_obj.data.edit_bones
    roots = [bone for bone in edit_bones if bone.parent is None]
    if len(roots) <= 1:
        bpy.ops.object.mode_set(mode="OBJECT")
        return

    root_bone = _choose_existing_root(roots)
    if not root_bone:
        root_bone = edit_bones.new(_unique_bone_name(edit_bones, "jx3_root"))
        head, tail = _root_span(roots)
        root_bone.head = head
        root_bone.tail = tail
        root_bone.roll = 0.0

    fixed_count = 0
    for bone in roots:
        if bone == root_bone:
            continue
        bone.parent = root_bone
        bone.use_connect = False
        fixed_count += 1

    bpy.ops.object.mode_set(mode="OBJECT")
    if fixed_count:
        report["messages"].append(f"{arm_obj.name}: 已将 {fixed_count} 个根骨挂到 {root_bone.name}。")


def _recalculate_roll(context: bpy.types.Context, arm_obj: bpy.types.Object, report: dict) -> None:
    bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.select_all(action="DESELECT")
    arm_obj.select_set(True)
    context.view_layer.objects.active = arm_obj
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.armature.select_all(action="SELECT")
    try:
        bpy.ops.armature.calculate_roll(type="GLOBAL_POS_Z")
        report["messages"].append(f"{arm_obj.name}: 已按全局 Z 轴重算骨骼 roll。")
    except RuntimeError:
        report["messages"].append(f"{arm_obj.name}: 骨骼 roll 重算失败，已保留原值。")
    finally:
        bpy.ops.object.mode_set(mode="OBJECT")


def _choose_existing_root(roots):
    preferred = ("bonesysparent", "root", "bip", "pelvis")
    for name in preferred:
        for bone in roots:
            if bone.name.lower() == name:
                return bone
    return None


def _root_span(roots):
    heads = [bone.head.copy() for bone in roots]
    if not heads:
        return Vector((0.0, 0.0, 0.0)), Vector((0.0, 0.0, 0.1))

    center = sum(heads, Vector((0.0, 0.0, 0.0))) / len(heads)
    tail = center + Vector((0.0, 0.0, 0.15))
    return center, tail


def _unique_bone_name(edit_bones, base_name: str) -> str:
    if base_name not in edit_bones:
        return base_name
    index = 1
    while f"{base_name}_{index:02d}" in edit_bones:
        index += 1
    return f"{base_name}_{index:02d}"


def _find_armature_modifier(mesh_obj: bpy.types.Object):
    for modifier in mesh_obj.modifiers:
        if modifier.type == "ARMATURE":
            return modifier
    return None


def _has_non_identity_rotation(obj: bpy.types.Object) -> bool:
    return any(abs(angle) > math.radians(0.01) for angle in obj.rotation_euler)


def _has_non_uniform_scale(obj: bpy.types.Object) -> bool:
    sx, sy, sz = obj.scale
    return (
        abs(sx - sy) > EPSILON
        or abs(sx - sz) > EPSILON
        or abs(sx - 1.0) > EPSILON
        or abs(sy - 1.0) > EPSILON
        or abs(sz - 1.0) > EPSILON
    )


def _has_animation(obj: bpy.types.Object) -> bool:
    return bool(obj.animation_data and (obj.animation_data.action or obj.animation_data.nla_tracks))
