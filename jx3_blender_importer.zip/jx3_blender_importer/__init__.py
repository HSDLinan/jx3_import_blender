"""Blender add-on entry point for importing JX3 FBX exports."""

bl_info = {
    "name": "JX3 Blender Importer",
    "author": "HSDLinan",
    "version": (0, 9, 0),
    "blender": (4, 3, 0),
    "location": "View3D > Sidebar > JX3",
    "description": "Import JX3 FBX files and restore Diffuse/Normal/MRE materials.",
    "category": "Import-Export",
}

import bpy
import importlib
import inspect
from bpy.props import BoolProperty, EnumProperty, FloatProperty, PointerProperty, StringProperty
from bpy.types import Operator, Panel, PropertyGroup

from . import armature
from . import importer
from . import materials
from . import render_setup


armature = importlib.reload(armature)
materials = importlib.reload(materials)
importer = importlib.reload(importer)
render_setup = importlib.reload(render_setup)


def _render_settings_update(self, context):
    if not context or not getattr(context, "scene", None):
        return
    settings = context.scene.jx3_importer_settings
    try:
        render_setup.apply_render_settings(
            context,
            render_pipeline=settings.render_pipeline,
            soft_glow=settings.render_soft_glow,
            hue=settings.render_hue,
            saturation=settings.render_saturation,
            lightness=settings.render_lightness,
            contrast=settings.render_contrast,
            dispersion=settings.render_dispersion,
            gamma=settings.render_gamma,
            color_temperature=settings.render_color_temperature,
            ao_factor=settings.render_ao_factor,
            ao_distance=settings.render_ao_distance,
            gi_factor=settings.render_gi_factor,
            gi_distance=settings.render_gi_distance,
        )
    except Exception as exc:
        print(f"[JX3 Importer] 渲染设置自动应用失败: {exc}")


class JX3_ImporterSettings(PropertyGroup):
    texture_dir: StringProperty(
        name="贴图目录",
        description="留空时自动使用 FBX 同级 tex 目录，或从已导入图片推断",
        subtype="DIR_PATH",
        default="",
    )
    emission_strength: FloatProperty(
        name="自发光强度",
        description="MRE 蓝色通道连接到 Emission Strength 时的倍率",
        default=1.0,
        min=0.0,
        soft_max=10.0,
    )
    use_diffuse_alpha: BoolProperty(
        name="自动修复半透明/遮罩",
        description="根据 Diffuse Alpha 自动处理眼部遮罩、头发和半透明纱袖；金属材质会保持不透明",
        default=True,
    )
    repair_armature: BoolProperty(
        name="修复骨骼",
        description="快速检查骨骼并修复 Mesh/Armature 关联",
        default=True,
    )
    deep_armature_repair: BoolProperty(
        name="深度骨骼修复（较慢）",
        description="执行对象变换应用、根骨重挂和骨骼 roll 重算；模型明显歪轴时再开启",
        default=False,
    )
    render_pipeline: EnumProperty(
        name="渲染管线",
        description="选择一键渲染设置要应用到 EEVEE 还是 Cycles",
        items=(
            ("EEVEE", "EEVEE", "使用 EEVEE / EEVEE Next 渲染管线"),
            ("CYCLES", "Cycles", "使用 Cycles 渲染管线"),
        ),
        default="EEVEE",
        update=_render_settings_update,
    )
    render_soft_glow: FloatProperty(
        name="柔光",
        description="合成器 Fog Glow 强度",
        default=0.35,
        min=0.0,
        max=1.0,
        update=_render_settings_update,
    )
    render_hue: FloatProperty(
        name="色相",
        description="合成器 Hue 值，0.5 为不偏移",
        default=0.5,
        min=0.0,
        max=1.0,
        update=_render_settings_update,
    )
    render_saturation: FloatProperty(
        name="饱和度",
        description="HSL 饱和度，1.0 为原始饱和度",
        default=1.0,
        min=0.0,
        soft_max=2.0,
        update=_render_settings_update,
    )
    render_lightness: FloatProperty(
        name="明度",
        description="HSL 明度/Value，1.0 为原始明度",
        default=1.0,
        min=0.0,
        soft_max=2.0,
        update=_render_settings_update,
    )
    render_contrast: FloatProperty(
        name="对比度",
        description="合成器 Bright/Contrast 的 Contrast 值",
        default=8.0,
        soft_min=-50.0,
        soft_max=50.0,
        update=_render_settings_update,
    )
    render_dispersion: FloatProperty(
        name="色散",
        description="合成器 Lens Distortion 的 Dispersion 值",
        default=0.015,
        min=0.0,
        soft_max=0.1,
        update=_render_settings_update,
    )
    render_gamma: FloatProperty(
        name="Gamma",
        description="合成器 Gamma 值",
        default=1.0,
        min=0.1,
        soft_max=3.0,
        update=_render_settings_update,
    )
    render_color_temperature: FloatProperty(
        name="色温",
        description="近似色温，低值偏暖，高值偏冷",
        default=6500.0,
        min=2000.0,
        max=11000.0,
        update=_render_settings_update,
    )
    render_ao_factor: FloatProperty(
        name="AO强度",
        description="环境光遮蔽强度",
        default=1.2,
        min=0.0,
        soft_max=5.0,
        update=_render_settings_update,
    )
    render_ao_distance: FloatProperty(
        name="AO距离",
        description="环境光遮蔽距离",
        default=3.0,
        min=0.0,
        soft_max=20.0,
        update=_render_settings_update,
    )
    render_gi_factor: FloatProperty(
        name="GI强度",
        description="全局光照/间接光强度",
        default=1.0,
        min=0.0,
        soft_max=5.0,
        update=_render_settings_update,
    )
    render_gi_distance: FloatProperty(
        name="GI距离",
        description="全局光照/间接光影响距离",
        default=3.0,
        min=0.0,
        soft_max=20.0,
        update=_render_settings_update,
    )


class JX3_OT_import_and_fix(Operator):
    bl_idname = "jx3.import_and_fix"
    bl_label = "导入 JX3 FBX"
    bl_description = "选择一个 JX3 导出的 FBX；导入时不检索贴图，但保留自定义属性"
    bl_options = {"REGISTER", "UNDO"}

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.fbx", options={"HIDDEN"})

    def execute(self, context):
        try:
            report = importer.import_only(
                context,
                self.filepath,
            )
            if report.get("texture_dir"):
                context.scene.jx3_importer_settings.texture_dir = report["texture_dir"]
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        self.report(
            {"INFO"},
            f"JX3 导入完成：导入 {report['objects']} 个对象。需要时再点材质或骨骼修复。",
        )
        return {"FINISHED"}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


class JX3_OT_fix_selected(Operator):
    bl_idname = "jx3.fix_selected"
    bl_label = "修复当前已导入对象"
    bl_description = "对当前选中的 Mesh/Armature 恢复材质并检查骨骼"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        settings = context.scene.jx3_importer_settings
        try:
            kwargs = {
                "texture_dir": bpy.path.abspath(settings.texture_dir) if settings.texture_dir else "",
                "emission_strength": settings.emission_strength,
                "repair_armature": settings.repair_armature,
            }
            if _supports_parameter(importer.fix_selected, "deep_armature_repair"):
                kwargs["deep_armature_repair"] = settings.deep_armature_repair
            if _supports_parameter(importer.fix_selected, "use_diffuse_alpha"):
                kwargs["use_diffuse_alpha"] = settings.use_diffuse_alpha

            report = importer.fix_selected(
                context,
                **kwargs,
            )
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        self.report(
            {"INFO"},
            f"JX3 修复完成：修复 {report['materials']['materials_fixed']} 个材质，"
            f"检查 {report['armatures']['armatures_seen']} 个骨架。",
        )
        return {"FINISHED"}


class JX3_OT_fix_materials_selected(Operator):
    bl_idname = "jx3.fix_materials_selected"
    bl_label = "仅修复材质贴图"
    bl_description = "先查找缺失贴图，再重建 Diffuse/Normal/MRE；自动处理透明遮罩和金属不透明"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        settings = context.scene.jx3_importer_settings
        try:
            report = importer.fix_materials_selected(
                context,
                texture_dir=bpy.path.abspath(settings.texture_dir) if settings.texture_dir else "",
                emission_strength=settings.emission_strength,
                use_diffuse_alpha=True,
                force_opaque=False,
            )
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        self.report(
            {"INFO"},
            f"材质贴图修复完成：贴图组 {report['texture_sets']}，"
            f"材质 {report['materials']['materials_fixed']}/{report['materials']['materials_seen']}。",
        )
        return {"FINISHED"}


class JX3_OT_fix_armature_selected(Operator):
    bl_idname = "jx3.fix_armature_selected"
    bl_label = "仅修复骨骼"
    bl_description = "只检查并修复当前选择对象的骨骼/Armature 关联，不处理材质"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        settings = context.scene.jx3_importer_settings
        try:
            report = importer.fix_armature_selected(
                context,
                deep_armature_repair=settings.deep_armature_repair,
            )
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        self.report(
            {"INFO"},
            f"骨骼修复完成：检查 {report['armatures']['armatures_seen']} 个骨架。",
        )
        return {"FINISHED"}


class JX3_OT_apply_render_settings(Operator):
    bl_idname = "jx3.apply_render_settings"
    bl_label = "一键渲染设置"
    bl_description = "设置柔光、色相、对比度、色散、Gamma、色温和 AO，并创建合成器节点"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        settings = context.scene.jx3_importer_settings
        try:
            report = render_setup.apply_render_settings(
                context,
                render_pipeline=settings.render_pipeline,
                soft_glow=settings.render_soft_glow,
                hue=settings.render_hue,
                saturation=settings.render_saturation,
                lightness=settings.render_lightness,
                contrast=settings.render_contrast,
                dispersion=settings.render_dispersion,
                gamma=settings.render_gamma,
                color_temperature=settings.render_color_temperature,
                ao_factor=settings.render_ao_factor,
                ao_distance=settings.render_ao_distance,
                gi_factor=settings.render_gi_factor,
                gi_distance=settings.render_gi_distance,
            )
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        self.report(
            {"INFO"},
            f"渲染设置完成：{report['pipeline']}，AO {report['ao_factor']}，GI {report['gi_factor']}。",
        )
        return {"FINISHED"}


class JX3_PT_importer_panel(Panel):
    bl_label = "JX3 Importer"
    bl_idname = "JX3_PT_importer_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "JX3"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.jx3_importer_settings

        notice_box = layout.box()
        notice_box.label(text="修复还原材质贴图可能需要2-5分钟，请耐心等待。")
        notice_box.label(text="by黑山渡Linan")

        layout.prop(settings, "texture_dir")
        layout.prop(settings, "emission_strength")
        layout.prop(settings, "repair_armature")
        layout.prop(settings, "deep_armature_repair")
        layout.prop(settings, "use_diffuse_alpha")
        layout.separator()
        layout.operator(JX3_OT_import_and_fix.bl_idname, icon="IMPORT")
        layout.operator(JX3_OT_fix_materials_selected.bl_idname, icon="MATERIAL")
        layout.operator(JX3_OT_fix_armature_selected.bl_idname, icon="ARMATURE_DATA")
        layout.operator(JX3_OT_fix_selected.bl_idname, icon="MOD_ARMATURE")
        layout.separator()
        render_box = layout.box()
        render_box.label(text="一键渲染设置")
        render_box.prop(settings, "render_pipeline")
        render_box.prop(settings, "render_soft_glow")
        render_box.prop(settings, "render_hue")
        render_box.prop(settings, "render_saturation")
        render_box.prop(settings, "render_lightness")
        render_box.prop(settings, "render_contrast")
        render_box.prop(settings, "render_dispersion")
        render_box.prop(settings, "render_gamma")
        render_box.prop(settings, "render_color_temperature")
        render_box.prop(settings, "render_ao_factor")
        render_box.prop(settings, "render_ao_distance")
        render_box.prop(settings, "render_gi_factor")
        render_box.prop(settings, "render_gi_distance")
        render_box.operator(JX3_OT_apply_render_settings.bl_idname, icon="RENDER_STILL")


classes = (
    JX3_ImporterSettings,
    JX3_OT_import_and_fix,
    JX3_OT_fix_selected,
    JX3_OT_fix_materials_selected,
    JX3_OT_fix_armature_selected,
    JX3_OT_apply_render_settings,
    JX3_PT_importer_panel,
)


def _supports_parameter(function, parameter_name):
    return parameter_name in inspect.signature(function).parameters


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.jx3_importer_settings = PointerProperty(type=JX3_ImporterSettings)


def unregister():
    if hasattr(bpy.types.Scene, "jx3_importer_settings"):
        del bpy.types.Scene.jx3_importer_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
